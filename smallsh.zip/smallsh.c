#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>

// constants and necessary global variables
#define MAX_COMMAND_LENGTH 2048
#define MAX_ARGUMENTS 512
int lastForegroundStatus = 0;
pid_t foregroundChildPid = -1;
int allowBackground = 1;

// Function prototypes
void sigintHandler(int signo);
void sigtstpHandler(int signo);
void setupSignalHandlers();
char* prompt();
char** tokenizeCommand(char* command);
void expand_pid(char *command);
void handleStatus(int status);
void executeCommand(char** args, int background);
void freeTokenizedCommand(char** args);

// seting up necessary signals
void setupSignalHandlers() {
    // Set up the signal handler for SIGINT
    signal(SIGINT, sigintHandler);

    // Set up the signal handler for SIGTSTP
    signal(SIGTSTP, sigtstpHandler);
}

// asks for prompt. This uses a standard colon.
char* prompt() {
    printf(": ");
    fflush(stdout);
    char* command = malloc(MAX_COMMAND_LENGTH);  // Allocate dynamic memory
    fgets(command, MAX_COMMAND_LENGTH, stdin);
    if (strlen(command) > 0 && command[strlen(command) - 1] == '\n') {
        command[strlen(command) - 1] = '\0';  // Remove the newline character
    }
    return command;
}

// if starts with # or the line is blank, nothing happens
int handleBlankAndComment(char* command){
    if(command[0] == '#' || strlen(command) == 0){
        return 1;
    }
    return 0;
}

// spliting up the command into tokens so different arguments can be processed.
char** tokenizeCommand(char* command){
    char* token;
    char** args = malloc(MAX_ARGUMENTS * sizeof(char*));  // Allocate dynamic memory
    // handle memory allocation failure
    if (args == NULL) {
        perror("malloc");
        exit(1);
    }
    int argCount = 0;
    // handle spacing
    token = strtok(command, " ");
    while (token != NULL && argCount < MAX_ARGUMENTS - 1) {
        args[argCount++] = strdup(token);  // Allocate memory for each token
        token = strtok(NULL, " ");
    }
    args[argCount] = NULL;
    return args;
}

// expand $ symbols by replacing with the PID number
void expand_pid(char *command) {
    char *pid_str = malloc(10);  // Assuming the process ID can be represented in 10 characters
    sprintf(pid_str, "%d", getpid());
    
    char *pos = strstr(command, "$$");
    while (pos != NULL) {
        // Replace "$$" with the process ID
        strncpy(pos, pid_str, strlen(pid_str));
        
        // Move to the next occurrence
        pos = strstr(command, "$$");
    }

    free(pid_str);
}

// handle the status command with either the exit status or last termination signal
void handleStatus(int status){
    // Print the exit status if the process terminated normally
    if (WIFEXITED(status)) {
        printf("exit value %d\n", WEXITSTATUS(status));
    }
    // Print the terminating signal if the process was terminated by a signal
    else if (WIFSIGNALED(status)) {
        printf("terminated by signal %d\n", WTERMSIG(status));
    }
}

// kill child process with SIGINT
void sigintHandler(int signo) {
    if (signo == SIGINT) {
        // Do nothing in the parent and background processes

        // In the foreground child process, terminate itself
        if (getpid() == foregroundChildPid) {
            exit(2);  // Use a different exit status to indicate termination by SIGINT
        }
    }
}

// Toggle between foreground and background processes with SIGTSTP
void sigtstpHandler(int signo) {
    if (signo == SIGTSTP) {
        if (allowBackground) {
            // Informative message when the shell receives SIGTSTP
            printf("\nEntering foreground-only mode (& is now ignored)\n");
            fflush(stdout);

            // Disable background processes
            allowBackground = 0;
        } else {
            // Informative message when returning to normal mode
            printf("\nExiting foreground-only mode\n");
            fflush(stdout);

            // Enable background processes
            allowBackground = 1;
        }
    }
}

// execute command for child process
void executeCommand(char** args, int background) {
    pid_t childPid = fork();
    // handle fork failure
    if (childPid == -1) {
        perror("fork");
        exit(1);
    } else if (childPid == 0) {
        // Child process

        // Set up signal handler for SIGINT in the child
        signal(SIGINT, SIG_DFL);

        // Check for output redirection and execute the command
        int i = 0;
        while (args[i] != NULL) {
            if (strcmp(args[i], ">") == 0) {
                // Output redirection detected, handle it if needed
                // ...
                break;
            }
            i++;
        }

        // Check for test -f command
        if (strcmp(args[0], "test") == 0 && strcmp(args[1], "-f") == 0 && args[2] != NULL) {
            if (access(args[2], F_OK) == 0) {
                // File exists
                printf("File exists\n");
                exit(0);  // Return 0 for true
            } else {
                // File does not exist
                printf("File does not exist\n");
                exit(1);  // Return 1 for false
            }
        }

        // Execute the command
        execvp(args[0], args);

        // If execvp fails, print an error message and exit
        perror("execvp");
        exit(1);
    } else {
        // Parent process
        if (!background) {
            // If it's a foreground process, set foregroundChildPid
            foregroundChildPid = childPid;
            // Wait for the child to finish
            int childStatus;
            waitpid(childPid, &childStatus, 0);

            // Check if the command was test -f and adjust the exit status
            if (WIFEXITED(childStatus) && WEXITSTATUS(childStatus) == 1) {
                printf("exit value 1\n");
            } else {
                lastForegroundStatus = childStatus;
            }

            foregroundChildPid = -1;  // Reset foregroundChildPid
        } else {
            // If it's a background process, print its process ID
            printf("background pid is %d\n", childPid);
            freeTokenizedCommand(args);
        }
    }
}

// free memory for all tokens of the command
void freeTokenizedCommand(char** args) {
    for (int i = 0; args[i] != NULL; ++i) {
        free(args[i]);
    }
    free(args);
}

// driver function for program
void main() {
    setupSignalHandlers();
    int background = 0;
    // continue running until "exit" is prompted
    while (1) {
        char* command = prompt();
        if (handleBlankAndComment(command)) {
            continue;
        }
        char** args = tokenizeCommand(command);
        expand_pid(command);
        // Check for background execution
        if (args != NULL && args[0] != NULL) {
            int i = 0;
            while (args[i] != NULL) {
                i++;
            }
            if (i > 0 && strcmp(args[i - 1], "&") == 0) {
                background = 1;
                args[i - 1] = NULL; // Remove the "&" from arguments
            } else {
                background = 0;
            }
        }
        // handle exit command
        if (strcmp(args[0], "exit") == 0) {
            exit(0);
        // handle cd command
        } else if (strcmp(args[0], "cd") == 0) {
            // Check if the command has an argument for the directory
            if (args[1] == NULL) {
                // Change to the home directory
                chdir(getenv("HOME"));
            } else {
                // Change to the specified directory
                if (chdir(args[1]) != 0) {
                    perror("cd"); // Print an error message if chdir fails
                }
            }
        // handle status command
        } else if (strcmp(args[0], "status") == 0) {
            // Check if any foreground process has been executed
            if (lastForegroundStatus == -1) {
                // No foreground process has been executed
                printf("exit value 0\n");
            } else {
                // Print the status of the last foreground process
                handleStatus(lastForegroundStatus);
            }
        // handle unknown command
        } else {
            pid_t childPid = fork();
            if (childPid == -1) {
                perror("fork");
                exit(1);
            } else if (childPid == 0) {
                // Child process
                // Check for input/output redirection and execute command
                executeCommand(args, background);
                exit(0);
            } else {
                // Parent process
                if (!background) {
                    // Wait for the child to finish if it's a foreground process
                    waitpid(childPid, &lastForegroundStatus, 0);
                } else {
                    // If it's a background process, print its process ID
                    printf("background pid is %d\n", childPid);
                }
                
                // Check if any background process has terminated
                pid_t terminatedChild;
                int childStatus;
                while ((terminatedChild = waitpid(-1, &childStatus, WNOHANG)) > 0) {
                    // Print the termination message for the background process
                    printf("background pid %d is done: ", terminatedChild);
                    handleStatus(childStatus);
                }
            }
        }
        freeTokenizedCommand(args);
    }
}