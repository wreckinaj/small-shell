WARNING! If you do not follow instructions and compile and run this code on flip, you may ruin
the school server! Be careful!

1. Unzip the zip file provided.
2. Create a new terminal.
3. Log into the OS1 server (not flip) with your ONID credentials.
4. cd into the folder.
5. Compile with the following line:
gcc smallsh.c -o smallsh -std=gnu99
6. Hit smallsh to get started with the shell!
7. To run the test script, type chmod +x ./p3testscript
8. Then hit ./p3testscript > mytestresults 2>&1